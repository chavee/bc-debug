/**
 * Appcelerator Titanium Mobile
 * Copyright (c) 2020 by Axway Appcelerator, Inc. All Rights Reserved.
 * Licensed under the terms of the Apache Public License
 * Please see the LICENSE included with this distribution for details.
 */

#import <UIKit/UIKit.h>

//! Project version number for AppceleratorBle.
FOUNDATION_EXPORT double AppceleratorBleVersionNumber;

//! Project version string for AppceleratorBle.
FOUNDATION_EXPORT const unsigned char AppceleratorBleVersionString[];

#import "AppceleratorBleModuleAssets.h"
